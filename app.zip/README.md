# Trading API

A minimal Python REST API built with FastAPI.

## Setup

```bash
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
```

## Run

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## Endpoints

- `GET /` - API welcome message
- `GET /health` - Health check
- `GET /api/v1/markets` - List sample markets
- `GET /api/v1/quote/{symbol}` - Get sample quote

## Docs

Open `http://localhost:8000/docs` in your browser after starting the server.
