from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="Trading API", version="1.0.0")


class MarketQuote(BaseModel):
    symbol: str
    price: float
    change_percent: float


@app.get("/")
async def root() -> dict:
    return {
        "message": "Trading API is running",
        "docs": "/docs",
    }


@app.get("/health")
async def health_check() -> dict:
    return {"status": "ok", "service": "trading-api"}


@app.get("/api/v1/markets")
async def list_markets() -> dict:
    return {
        "markets": [
            {"symbol": "AAPL", "name": "Apple Inc."},
            {"symbol": "MSFT", "name": "Microsoft"},
            {"symbol": "NVDA", "name": "NVIDIA"},
        ]
    }


@app.get("/api/v1/quote/{symbol}")
async def get_quote(symbol: str) -> MarketQuote:
    sample_prices = {
        "AAPL": 214.32,
        "MSFT": 428.15,
        "NVDA": 124.8,
    }

    price = sample_prices.get(symbol.upper(), 100.0)
    return MarketQuote(
        symbol=symbol.upper(),
        price=price,
        change_percent=1.25,
    )
